function esPalindromo(cadena) {
    let regex = /^\D*$/;

    while (!regex.test(cadena)) {
        cadena = prompt("No puede contener números.\nEscriba otra frase: ");
    }

    array = cadena.split("");
    arrayInvertido = cadena.split("").reverse();


    return array == arrayInvertido;
}